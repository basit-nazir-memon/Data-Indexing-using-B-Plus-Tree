#pragma once
#include <iostream>
#include <string>
using namespace std;
class fileNode {
public:
	string location;
};
